/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./public/**/*.{html,js}"],
  theme: {

    fontFamily : {
      "dancing" : "var(--dancing)",
    },
    container : {
      center : true,
      "padding" : "16px",
    },
    extend: {

      colors : {
        "orange-1" : "var(--orange)",
      },

      height : {

        "achawlay" : "100vh",
      },

      width : {

        "7/5" : "75%",
      },

    },
  },
  plugins: [],
}

