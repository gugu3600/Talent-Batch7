const menu = document.querySelector(".hamburger"),
aside = document.getElementById("side-bar"),
main = document.getElementById("main-item"),
footer = document.querySelector(".footer");


// console.log(paragraphs);

let open = true;





menu.addEventListener("click",function(){

    if(open){

        aside.classList.replace("w-1/4","w-0");
        main.classList.replace("w-7/5","w-full");
        footer.classList.replace("w-9/12","w-full");
        menu.classList.remove("cross");
        open = false;
    }

    else{

        aside.classList.replace("w-0","w-1/4");
        main.classList.replace("w-full","w-7/5");
        footer.classList.replace("w-full","w-9/12");
        menu.classList.add("cross");
        open = true;

    }
})


const heading = document.querySelector(".title-box"),
paragraphs = document.querySelectorAll(".paragraph");

let titles = heading.children;


for(let i = 0 ; i < titles.length ; i++){

    titles[i].addEventListener("click",function(){

        
        
        for (let j = 0; j < titles.length; j++) {
            titles[j].classList.remove("active");
            paragraphs[j].classList.add("hidden");
        }

        this.classList.add("active");
        paragraphs[i].classList.remove("hidden");
    });
}